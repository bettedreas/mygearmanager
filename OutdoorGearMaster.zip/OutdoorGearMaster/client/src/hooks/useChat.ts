// This file is now replaced by direct state management in ChatInterface.tsx
// Keeping this for compatibility but it's no longer used
export function useChat() {
  return {};
}